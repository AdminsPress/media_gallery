<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Media Gallery</title>
	<link rel="stylesheet" type="text/css" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
</head>
<body>
<?php include 'media_body_beta.php'; ?>
<script src="./node_modules/jquery/dist/jquery.min.js"></script>
<script src="./node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="./media_gallery_beta.js"></script>
<!-- <script src="./node_modules/jquery/dist/jquery.min.js"></script> -->
<script>
	$('#adpModal').modal('show');
</script>
</body>
</html>